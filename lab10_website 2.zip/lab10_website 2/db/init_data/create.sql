DROP TABLE IF EXISTS breweries CASCADE;
CREATE TABLE IF NOT EXISTS breweries (
  id SERIAL PRIMARY KEY,
  brewery_name VARCHAR(50) NOT NULL, 
  review VARCHAR(300) NOT NULL,
  review_date DATE NOT NULL
);
ALTER ROLE postgres SET search_path TO reviews, public;