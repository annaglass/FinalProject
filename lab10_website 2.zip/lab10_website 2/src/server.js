// load components
//import axios from 'axios';
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
const axios = require('axios');

// create database connection
var pgp = require('pg-promise')();

const dev_dbConfig = {
	host: 'db',
	port: 5432,
	database: process.env.POSTGRES_DB,
	user: process.env.POSTGRES_USER,
	password: process.env.POSTGRES_PASSWORD
};

const isProduction = process.env.NODE_ENV === 'production';
const dbConfig = isProduction ? process.env.DATABASE_URL : dev_dbConfig;

if (isProduction) {
	pgp.pg.defaults.ssl = { rejectUnauthorized: false };
}

const db = pgp(dbConfig);

// set the view engine to ejs
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(express.static(__dirname + '/'));

// home page
app.get('/', function (req, res) {
	res.render('pages/home', {
		my_title: "Home Page",
		items: '',
		error: false,
		message: ''
	});
});

// review page
app.get('/reviews', function (req, res) {
	res.render('pages/reviews', {
		my_title: "Reviews"
	});
});

// search
app.post('/get_feed', function (req, res) {
	var city = req.body.city;
	var api_key = '2fd27d9a-889d-452c-aeab-37b611adf3b0';

	if (city) {
		axios({
			url: `http://api.openbrewerydb.org/breweries/search?query=${city}`,
			method: 'GET',
			dataType: 'json',
		})
			.then(items => {
				res.render('pages/home', {
					my_title: "search",
					items: items.data,
					error: false,
					message: 'Success.'
				});
			})
			.catch(error => {
				console.log(error);
				res.render('pages/home', {
					my_title: "search",
					items: '',
					error: true,
					message: error
				})
			});
	}
	else {
		res.render('pages/home', {
			my_title: "search",
			items: '',
			error: true,
			message: 'Error.'
		})
	}
});

// insert review into db
app.post('/insert_review', function (req, res) {
	var id = req.body.brew_id;
	var brewery = req.body.brew_name;
	var review = req.body.review;
	var insert_statement = "INSERT INTO breweries(id, brewery_name, review, review_date) VALUES('" + brewery + "', '" + review + "', current_date );";

	db.task('insert_review', task => {
		return task.batch([
			task.any(insert_statement),
		]);
	})
		.then(response => {
			res.render('pages/reviews', {
				my_title: "Reviews",
			})
		})
		.catch(err => {
			res.render('pages/reviews', {
				my_title: "Reviews",
				items: '',
				error: true,
				message: error
			})
		});
});

app.get('/retrieve', function (req, res) {
	var query = "SELECT * FROM brewery_reviews;";
	db.task('pull reviews', task => {
		task.any(query)
	})
		.then(response => {
			console.log(response);
			res.render('/pages/reviews', {
				my_title: "Reviews",
				items: res,
				error: false,
				message: ''
			});
		})
		.catch(err => {
			console.log(err);
		})
});


/*filter reviews
app.post('/filter', function (req, res) {
	var brewery = req.body.brewery_name;
	var api_key = '2fd27d9a-889d-452c-aeab-37b611adf3b0';

	if (brewery) {
		axios({
			url: `http://api.openbrewerydb.org/breweries/search?query=${brewery}`,
			method: 'GET',
			dataType: 'json',
		})
			// load reviews with matching items
			.then(items => {
				res.render('pages/reviews', {
					my_title: "Filtered Reviews",
					items: items.data,
					error: false,
					message: 'Success.'
				});
			})
			// if brewery can't be found, load all reviews
			.catch(error => {
				console.log(error);
				res.render('pages/Reviews', {
					my_title: "Reviews",
					items: '',
					error: true,
					message: error
				})
			});
	}
	// if empty, load all reviews
	else {
		res.render('pages/Reviews', {
			my_title: "Reviews",
			items: items,
			error: false,
			message: "Couldn't find matching breweries"
		})
	}
});*/

// local host 3000
const server = app.listen(process.env.PORT || 3000, () => {
	console.log(`Express running → PORT ${server.address().port}`);
});